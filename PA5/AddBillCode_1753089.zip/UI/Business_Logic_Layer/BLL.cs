﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;
using Entity_Object;

namespace Business_Logic_Layer
{
    public class BLL
    {

        public bool CheckProductExist(int pid)
        {
            var pds = new DAL().GetProductsInfoFromDB();

            foreach (var pd in pds)
            {
                if (pd.prod_id == pid)
                    return true;
            }
            return false;
        }

        public bool CheckProductStock(int pid, int qty)
        {
            var pdstks = new DAL().GetProductsStockFromDB();

            foreach (var pdstk in pdstks)
            {
                if (pdstk.product_id == pid && pdstk.product_remaning >= qty)
                    return true;
            }
            return false;
        }


        public Products GetProduct(int pid)
        {
            var pds = new DAL().GetProductsInfoFromDB();
            foreach (var pd in pds)
            {
                if (pd.prod_id == pid)
                    return pd;
            }
            return null;
        }


        public bool AddBill(List<BillsDetail> bds, Bills b)
        {
            try
            {
                var addbill = new Data_Access_Layer.DAL().AddBillToDB(b);
                if (!addbill)
                    return addbill;
                foreach(var bd in bds)
                {
                    var adddetail = new Data_Access_Layer.DAL().AddBillDetailToDB(bd);
                    if (!adddetail)
                        return adddetail;
                    addbill = addbill && adddetail;
                }
                return addbill;
            }
            catch
            {
                return false;
            }
        }

        public int GetAutoBillID()
        {
            var bid = new Data_Access_Layer.DAL().GetAutoBillIDFromDB();
            return bid;
        }

        public Bills GetBillsWithBillID(int bid)
        {
            var b = new Data_Access_Layer.DAL().GetBillFromDB(bid);
            return b;
        }

        public List<BillsDetail> GetBillsDetailWithBillID(int bid)
        {
            var bds = new Data_Access_Layer.DAL().GetBillDetailsFromDB(bid);
            return bds;
        }
    }
}

﻿namespace UI
{
    partial class ViewBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_BillID = new System.Windows.Forms.Label();
            this.listView_BillDetail = new System.Windows.Forms.ListView();
            this.label_CreateDate = new System.Windows.Forms.Label();
            this.label_StaffID = new System.Windows.Forms.Label();
            this.label_bid = new System.Windows.Forms.Label();
            this.label_credate = new System.Windows.Forms.Label();
            this.label_stfid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label_BillID
            // 
            this.label_BillID.AutoEllipsis = true;
            this.label_BillID.BackColor = System.Drawing.SystemColors.Control;
            this.label_BillID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_BillID.Location = new System.Drawing.Point(43, 39);
            this.label_BillID.Name = "label_BillID";
            this.label_BillID.Size = new System.Drawing.Size(117, 36);
            this.label_BillID.TabIndex = 53;
            this.label_BillID.Text = "Bill ID: ";
            this.label_BillID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // listView_BillDetail
            // 
            this.listView_BillDetail.HideSelection = false;
            this.listView_BillDetail.Location = new System.Drawing.Point(43, 148);
            this.listView_BillDetail.Name = "listView_BillDetail";
            this.listView_BillDetail.Size = new System.Drawing.Size(1092, 439);
            this.listView_BillDetail.TabIndex = 48;
            this.listView_BillDetail.UseCompatibleStateImageBehavior = false;
            // 
            // label_CreateDate
            // 
            this.label_CreateDate.AutoEllipsis = true;
            this.label_CreateDate.BackColor = System.Drawing.SystemColors.Control;
            this.label_CreateDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_CreateDate.Location = new System.Drawing.Point(43, 90);
            this.label_CreateDate.Name = "label_CreateDate";
            this.label_CreateDate.Size = new System.Drawing.Size(236, 36);
            this.label_CreateDate.TabIndex = 54;
            this.label_CreateDate.Text = "Create Date: ";
            this.label_CreateDate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_StaffID
            // 
            this.label_StaffID.AutoEllipsis = true;
            this.label_StaffID.BackColor = System.Drawing.SystemColors.Control;
            this.label_StaffID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_StaffID.Location = new System.Drawing.Point(705, 39);
            this.label_StaffID.Name = "label_StaffID";
            this.label_StaffID.Size = new System.Drawing.Size(136, 36);
            this.label_StaffID.TabIndex = 55;
            this.label_StaffID.Text = "Staff ID: ";
            this.label_StaffID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_bid
            // 
            this.label_bid.AutoEllipsis = true;
            this.label_bid.BackColor = System.Drawing.SystemColors.Control;
            this.label_bid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bid.Location = new System.Drawing.Point(233, 39);
            this.label_bid.Name = "label_bid";
            this.label_bid.Size = new System.Drawing.Size(373, 36);
            this.label_bid.TabIndex = 56;
            this.label_bid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_credate
            // 
            this.label_credate.AutoEllipsis = true;
            this.label_credate.BackColor = System.Drawing.SystemColors.Control;
            this.label_credate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_credate.Location = new System.Drawing.Point(233, 90);
            this.label_credate.Name = "label_credate";
            this.label_credate.Size = new System.Drawing.Size(373, 36);
            this.label_credate.TabIndex = 58;
            this.label_credate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_stfid
            // 
            this.label_stfid.AutoEllipsis = true;
            this.label_stfid.BackColor = System.Drawing.SystemColors.Control;
            this.label_stfid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stfid.Location = new System.Drawing.Point(847, 39);
            this.label_stfid.Name = "label_stfid";
            this.label_stfid.Size = new System.Drawing.Size(288, 36);
            this.label_stfid.TabIndex = 59;
            this.label_stfid.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ViewBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1188, 624);
            this.Controls.Add(this.label_stfid);
            this.Controls.Add(this.label_credate);
            this.Controls.Add(this.label_bid);
            this.Controls.Add(this.label_StaffID);
            this.Controls.Add(this.label_CreateDate);
            this.Controls.Add(this.label_BillID);
            this.Controls.Add(this.listView_BillDetail);
            this.Name = "ViewBill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewBill";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label_BillID;
        private System.Windows.Forms.ListView listView_BillDetail;
        private System.Windows.Forms.Label label_CreateDate;
        private System.Windows.Forms.Label label_StaffID;
        private System.Windows.Forms.Label label_bid;
        private System.Windows.Forms.Label label_credate;
        private System.Windows.Forms.Label label_stfid;
    }
}
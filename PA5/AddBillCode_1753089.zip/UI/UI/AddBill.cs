﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entity_Object;
using Business_Logic_Layer;

namespace UI
{
    public partial class AddBill : Form
    {
        List<BillsDetail> bds = new List<BillsDetail>();
        int ttl_amt = 0;
        decimal ttl_uprice = 0;
        clsResize _form_resize;
        int staffid = -1;
        public AddBill(int stfid)
        {
            InitializeComponent();
            staffid = stfid;
            LoadListView();
            LoadAutoID();
            

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }
        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void AddBill_Load(object sender, EventArgs e)
        {

        }

        private void LoadAutoID()
        {
            int bid = new Business_Logic_Layer.BLL().GetAutoBillID();
            label_AutoBillID.Text = bid.ToString();
            label_AutoStaffID.Text = staffid.ToString();
        }
        private void LoadListView()
        {
            listView_BillDetail.Columns.Add("Name", 350);
            listView_BillDetail.Columns.Add("Amount", 150);
            listView_BillDetail.Columns.Add("Unit Price", 250);

            String[] tt = new String[3];
            tt[0] = "Total";
            tt[1] = "0";
            tt[2] = "0";
            ListViewItem total = new ListViewItem(tt);
            listView_BillDetail.Items.Add(total);
            listView_BillDetail.View = View.Details;
        }

        private void button_AddItem_Click(object sender, EventArgs e)
        {
            if (textBox_ProdID.Text == "")
            {
                MessageBox.Show("Please enter product ID.");
                return;
            }

            foreach (char x in textBox_ProdID.Text)
            {
                if (x < 48 || x > 57)
                {
                    MessageBox.Show("Invalid product ID. Please enter again");
                    return;
                }
            }
            
            int pid = int.Parse(textBox_ProdID.Text);
            int qty;
            foreach (char x in textBox_Qty.Text)
            {
                if (x < 48 || x > 57)
                {
                    MessageBox.Show("Invalid quantityt. Please enter again");
                    return;
                }
            }
            if (textBox_Qty.Text == "")
            {
                qty = 1;
            }
            else
            {
                foreach (var x in textBox_Qty.Text)
                {
                    if (x < 48 && x > 57)
                    {
                        MessageBox.Show("Invalid quantity. Please enter again");
                    }
                }
                qty = int.Parse(textBox_Qty.Text);
            }

            textBox_ProdID.Text = "";
            textBox_Qty.Text = "";

            bool ck = new BLL().CheckProductExist(pid);
            if (!ck)
            {
                MessageBox.Show("Product doesn't exist. Please enter another one.");
                return;
            }

            ck = new BLL().CheckProductStock(pid, qty);
            if (!ck)
            {
                MessageBox.Show("Product doesn't have enough stock. Please try another one.");
                return;
            }

            foreach (var bd in bds)
            {
                if (bd.product_id == pid)
                {
                    bd.unit_price = (bd.unit_price / bd.number_of_products) * (bd.number_of_products + qty);
                    bd.number_of_products = bd.number_of_products + qty;
                    ReLoadBillsDetail();
                    return;
                }
            }

            var pd = new BLL().GetProduct(pid);
            decimal uprice = Decimal.Parse(pd.prod_price.ToString()) * qty;
            int bid = Int32.Parse(label_AutoBillID.Text);
            var nbd = new BillsDetail(bid, pid, qty, uprice);
            bds.Add(nbd);
            ReLoadBillsDetail();

        }


        private void ReLoadBillsDetail()
        {
            listView_BillDetail.BeginUpdate();
            listView_BillDetail.Clear();

            listView_BillDetail.Columns.Add("Name", 350);
            listView_BillDetail.Columns.Add("Amount", 150);
            listView_BillDetail.Columns.Add("Unit Price", 250);
            int tt_amt = 0;
            decimal tt_uprice = 0;
            foreach (var bd in bds)
            {
                String[] d = new String[3];
                var pd = new Business_Logic_Layer.BLL().GetProduct(bd.product_id);
             
                d[0] = pd.prod_name;
                d[1] = bd.number_of_products.ToString();
                d[2] = bd.unit_price.ToString();
               
                tt_amt = tt_amt + Int32.Parse(d[1]);
                tt_uprice = tt_uprice + Decimal.Parse(d[2]);

                ListViewItem item = new ListViewItem(d);
                listView_BillDetail.Items.Add(item);
            }
            
            ttl_amt = tt_amt;
            ttl_uprice = tt_uprice;
            String[] tt = new String[3];
            tt[0] = "Total";
            tt[1] = tt_amt.ToString();
            tt[2] = tt_uprice.ToString();
            ListViewItem total = new ListViewItem(tt);
            listView_BillDetail.Items.Add(total);

            listView_BillDetail.View = View.Details;
            listView_BillDetail.EndUpdate();
        }

        private void button_AddBill_Click(object sender, EventArgs e)
        {
           
            int bid = Int32.Parse(label_AutoBillID.Text);

            var bill = new Bills(bid, Convert.ToDecimal(ttl_amt), ttl_uprice, 0, ttl_uprice - 0, staffid);
            if (bds.Count() == 0)
            {
                MessageBox.Show("There are no product in bill. Please add product and try again.");
                return;
            }
            var add = new Business_Logic_Layer.BLL().AddBill(bds, bill);
            if (!add)
            {
                MessageBox.Show("Add bill failed");
                return;
            }
            else
            {
                MessageBox.Show("Add bill succeed");
                this.Hide();
                ViewBill viewBill = new ViewBill(bid);
                viewBill.ShowDialog();
                this.Close();
            }
            
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
          
            this.Close();
        }
    }
}

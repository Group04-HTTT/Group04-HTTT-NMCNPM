﻿using Business_Logic_Layer;
using Entity_Object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class ImportProduct : Form
    {
        private Products product = null;
        public ImportProduct()
        {
            InitializeComponent();
        }
        //textBox_Product_ID.Text == "" ||
        private void submit_Click_1(object sender, EventArgs e)
        {
            if ( textBox_Product_Type_ID.Text == "" || textBox_Product_Name.Text == "" || textBox_Product_Price.Text == "")
            {
                MessageBox.Show("You don't fill in !!!", "THÔNG BÁO");
            }
            else
            {
                var new_product = new Products();
              //  new_product.prod_id = Int32.Parse(textBox_Product_ID.Text);
                new_product.prodtype_id = Int32.Parse(textBox_Product_Type_ID.Text);
                new_product.prod_name = textBox_Product_Name.Text;
                new_product.prod_price = Decimal.Parse(textBox_Product_Price.Text);
                var servise = new BLL();
                product = servise.Add_Product(new_product);
                MessageBox.Show("Add product thành công vào database", "THÔNG BÁO");
            }                         
        }

        private void ImportProduct_Load(object sender, EventArgs e)
        {

        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

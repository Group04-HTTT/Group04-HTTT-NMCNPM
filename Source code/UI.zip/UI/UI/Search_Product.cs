﻿using Business_Logic_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Search_Product : Form
    {
        public Search_Product()
        {
            InitializeComponent();
        }

        private void button_Search_Product_Click(object sender, EventArgs e)
        {
            BLL bll = new BLL();
            dataGridView1.DataSource = bll.searchProductName(textBox_Search_Product.Text);
        }

        private void button_Search_ID_Click(object sender, EventArgs e)
        {
            BLL bll = new BLL();
            dataGridView1.DataSource = bll.searchProductID(Int32.Parse(textBox_Search_ID.Text));
        }
    }
}

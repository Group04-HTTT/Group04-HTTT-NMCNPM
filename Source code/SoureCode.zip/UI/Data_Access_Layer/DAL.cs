﻿using Entity_Object;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class DAL
    {
        
        public static string connectionString = @"Data Source=LAPTOP-LONG-LY\SQLEXPRESS; Initial Catalog=convinience_store;Integrated Security=True";
        public OleDbConnection Connected()
        {
            string path = "set_Connection.txt";
            var reader = new StreamReader(path);
            var query = reader.ReadLine();
            OleDbConnection oldbconnection = new OleDbConnection();
            oldbconnection.ConnectionString = query;
            //filename;
            oldbconnection.Open();
            return oldbconnection;
        }
        public List<Staffs> GetStaffFrom_Database()
        {
            var staff = new List<Staffs>();
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = "select * from STAFF";
            var er = oldbcmd.ExecuteReader();
            while (er.Read())
            {
                staff.Add(new Staffs(er.GetInt32(0), er.GetInt32(1), er.GetString(2), er.GetString(3), er.GetString(4), er.GetDateTime(5), er.GetInt32(6)));
            }
            oldbcn.Close();
            return staff;
        }
        public Products Add_Product_DB(Products new_product)
        {
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = $"insert into PRODUCT (PRODUCT_ID, PRODUCT_TYPE_ID, PRODUCT_NAME, PRODUCT_PRICE) values({new_product.prod_id}, {new_product.prodtype_id}, '{new_product.prod_name}', {new_product.prod_price});";
            oldbcmd.ExecuteNonQuery();
            oldbcn.Close();
            return new_product;
        }

        // Phung
        public DataTable ExecuteQueryName(string query, string name)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@product_name", name);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        public DataTable ExecuteQueryID(string query, int id)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@product_id", id);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }
    }
}

﻿namespace UI
{
    partial class Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Staff));
            this.button_Search = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_Search_Member = new System.Windows.Forms.Button();
            this.button_AddBill = new System.Windows.Forms.Button();
            this.button_ExportBill = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Search.Image = ((System.Drawing.Image)(resources.GetObject("button_Search.Image")));
            this.button_Search.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_Search.Location = new System.Drawing.Point(12, 147);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(194, 156);
            this.button_Search.TabIndex = 25;
            this.button_Search.Text = "Search product";
            this.button_Search.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_Search.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_Search.UseMnemonic = false;
            this.button_Search.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(237, 147);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(189, 156);
            this.button1.TabIndex = 26;
            this.button1.Text = "Register member";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button_Search_Member
            // 
            this.button_Search_Member.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Search_Member.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search_Member.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Search_Member.Image = ((System.Drawing.Image)(resources.GetObject("button_Search_Member.Image")));
            this.button_Search_Member.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_Search_Member.Location = new System.Drawing.Point(729, 147);
            this.button_Search_Member.Name = "button_Search_Member";
            this.button_Search_Member.Size = new System.Drawing.Size(184, 156);
            this.button_Search_Member.TabIndex = 27;
            this.button_Search_Member.Text = "Search member";
            this.button_Search_Member.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_Search_Member.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_Search_Member.UseMnemonic = false;
            this.button_Search_Member.UseVisualStyleBackColor = false;
            // 
            // button_AddBill
            // 
            this.button_AddBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddBill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddBill.Image = ((System.Drawing.Image)(resources.GetObject("button_AddBill.Image")));
            this.button_AddBill.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_AddBill.Location = new System.Drawing.Point(962, 147);
            this.button_AddBill.Name = "button_AddBill";
            this.button_AddBill.Size = new System.Drawing.Size(174, 156);
            this.button_AddBill.TabIndex = 28;
            this.button_AddBill.Text = "Add bill";
            this.button_AddBill.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_AddBill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_AddBill.UseMnemonic = false;
            this.button_AddBill.UseVisualStyleBackColor = false;
            // 
            // button_ExportBill
            // 
            this.button_ExportBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_ExportBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_ExportBill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_ExportBill.Image = ((System.Drawing.Image)(resources.GetObject("button_ExportBill.Image")));
            this.button_ExportBill.Location = new System.Drawing.Point(482, 147);
            this.button_ExportBill.Name = "button_ExportBill";
            this.button_ExportBill.Size = new System.Drawing.Size(183, 156);
            this.button_ExportBill.TabIndex = 29;
            this.button_ExportBill.Text = "Export Bill";
            this.button_ExportBill.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_ExportBill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_ExportBill.UseMnemonic = false;
            this.button_ExportBill.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(470, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 67);
            this.label1.TabIndex = 30;
            this.label1.Text = "STAFF";
            // 
            // Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 337);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_ExportBill);
            this.Controls.Add(this.button_AddBill);
            this.Controls.Add(this.button_Search_Member);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_Search);
            this.Name = "Staff";
            this.Text = "Staff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_Search_Member;
        private System.Windows.Forms.Button button_AddBill;
        private System.Windows.Forms.Button button_ExportBill;
        private System.Windows.Forms.Label label1;
    }
}
﻿namespace UI
{
    partial class Delete_Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button_Add;
            System.Windows.Forms.Button button_Search;
            System.Windows.Forms.Button button_Delete;
            this.listView_Staff_AtStore = new System.Windows.Forms.ListView();
            this.Staff_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_phone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_addr = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_dob = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_pos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_socialid = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_gender = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Staff_pass = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label1 = new System.Windows.Forms.Label();
            button_Add = new System.Windows.Forms.Button();
            button_Search = new System.Windows.Forms.Button();
            button_Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_Add
            // 
            button_Add.BackColor = System.Drawing.SystemColors.MenuHighlight;
            button_Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Add.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Add.Location = new System.Drawing.Point(360, 383);
            button_Add.Name = "button_Add";
            button_Add.Size = new System.Drawing.Size(172, 55);
            button_Add.TabIndex = 12;
            button_Add.Text = "Add";
            button_Add.UseVisualStyleBackColor = false;
            // 
            // button_Search
            // 
            button_Search.BackColor = System.Drawing.SystemColors.Highlight;
            button_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Search.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Search.Location = new System.Drawing.Point(22, 383);
            button_Search.Name = "button_Search";
            button_Search.Size = new System.Drawing.Size(172, 55);
            button_Search.TabIndex = 13;
            button_Search.Text = "Search";
            button_Search.UseVisualStyleBackColor = false;
            button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // button_Delete
            // 
            button_Delete.BackColor = System.Drawing.Color.Red;
            button_Delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Delete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Delete.Location = new System.Drawing.Point(565, 383);
            button_Delete.Name = "button_Delete";
            button_Delete.Size = new System.Drawing.Size(172, 55);
            button_Delete.TabIndex = 14;
            button_Delete.Text = "Delete";
            button_Delete.UseVisualStyleBackColor = false;
            // 
            // listView_Staff_AtStore
            // 
            this.listView_Staff_AtStore.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Staff_ID,
            this.Staff_Name,
            this.Staff_phone,
            this.Staff_addr,
            this.Staff_dob,
            this.Staff_pos,
            this.Staff_socialid,
            this.Staff_gender,
            this.Staff_pass});
            this.listView_Staff_AtStore.HideSelection = false;
            this.listView_Staff_AtStore.Location = new System.Drawing.Point(22, 109);
            this.listView_Staff_AtStore.Name = "listView_Staff_AtStore";
            this.listView_Staff_AtStore.Size = new System.Drawing.Size(715, 266);
            this.listView_Staff_AtStore.TabIndex = 0;
            this.listView_Staff_AtStore.UseCompatibleStateImageBehavior = false;
            this.listView_Staff_AtStore.View = System.Windows.Forms.View.Details;
            // 
            // Staff_ID
            // 
            this.Staff_ID.Text = "ID";
            this.Staff_ID.Width = 71;
            // 
            // Staff_Name
            // 
            this.Staff_Name.Text = "Name";
            this.Staff_Name.Width = 74;
            // 
            // Staff_phone
            // 
            this.Staff_phone.Text = "Phone";
            this.Staff_phone.Width = 79;
            // 
            // Staff_addr
            // 
            this.Staff_addr.Text = "Address";
            this.Staff_addr.Width = 75;
            // 
            // Staff_dob
            // 
            this.Staff_dob.Text = "DateOfBirth";
            this.Staff_dob.Width = 81;
            // 
            // Staff_pos
            // 
            this.Staff_pos.Text = "Position";
            this.Staff_pos.Width = 62;
            // 
            // Staff_socialid
            // 
            this.Staff_socialid.Text = "Socialid";
            this.Staff_socialid.Width = 80;
            // 
            // Staff_gender
            // 
            this.Staff_gender.Text = "Gender";
            this.Staff_gender.Width = 71;
            // 
            // Staff_pass
            // 
            this.Staff_pass.Text = "Password";
            this.Staff_pass.Width = 88;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(194, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(413, 76);
            this.label1.TabIndex = 1;
            this.label1.Text = "Staff at store";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Delete_Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(button_Delete);
            this.Controls.Add(button_Search);
            this.Controls.Add(button_Add);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView_Staff_AtStore);
            this.Name = "Delete_Staff";
            this.Text = "Delete_Staff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView_Staff_AtStore;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ColumnHeader Staff_ID;
        private System.Windows.Forms.ColumnHeader Staff_Name;
        private System.Windows.Forms.ColumnHeader Staff_phone;
        private System.Windows.Forms.ColumnHeader Staff_addr;
        private System.Windows.Forms.ColumnHeader Staff_dob;
        private System.Windows.Forms.ColumnHeader Staff_pos;
        private System.Windows.Forms.ColumnHeader Staff_socialid;
        private System.Windows.Forms.ColumnHeader Staff_gender;
        private System.Windows.Forms.ColumnHeader Staff_pass;
    }
}
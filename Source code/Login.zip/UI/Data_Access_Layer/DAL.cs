﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer
{
    public class DAL
    {
        public OleDbConnection Connected()
        {
            string path = "set_Connection.txt";
            var reader = new StreamReader(path);
            var query = reader.ReadLine();
            OleDbConnection oldbconnection = new OleDbConnection();
            oldbconnection.ConnectionString = query;
            //filename;
            oldbconnection.Open();
            return oldbconnection;
        }
    }
}

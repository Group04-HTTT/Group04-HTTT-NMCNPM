﻿using LoginModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Logic_Layer
{
    public class BLL
    {
        dbContext db;
        public BLL()
        {
            db = new dbContext();
        }
        public LOGIN getLoginByUsername(string username)
        {
            try
            {
                return db.LOGINs.FirstOrDefault(Login => Login.USERNAME.Equals(username)); 
            }
            catch (Exception)
            {

                return null;
            }
        }
    }
}

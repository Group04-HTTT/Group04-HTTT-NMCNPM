﻿namespace UI
{
    partial class Search_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button_Search_Product;
            this.textBox_Search_Product = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            button_Search_Product = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox_Search_Product
            // 
            this.textBox_Search_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Search_Product.Location = new System.Drawing.Point(12, 113);
            this.textBox_Search_Product.Name = "textBox_Search_Product";
            this.textBox_Search_Product.Size = new System.Drawing.Size(536, 45);
            this.textBox_Search_Product.TabIndex = 10;
            // 
            // button_Search_Product
            // 
            button_Search_Product.BackColor = System.Drawing.SystemColors.MenuHighlight;
            button_Search_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Search_Product.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Search_Product.Location = new System.Drawing.Point(554, 109);
            button_Search_Product.Name = "button_Search_Product";
            button_Search_Product.Size = new System.Drawing.Size(172, 55);
            button_Search_Product.TabIndex = 12;
            button_Search_Product.Text = "Search";
            button_Search_Product.UseVisualStyleBackColor = false;
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(12, 193);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(714, 248);
            this.listView1.TabIndex = 13;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(42, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(528, 48);
            this.label1.TabIndex = 14;
            this.label1.Text = "Search Information Product";
            // 
            // Search_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 462);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(button_Search_Product);
            this.Controls.Add(this.textBox_Search_Product);
            this.Name = "Search_Product";
            this.Text = "Search_Product";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Search_Product;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label1;
    }
}
﻿using Business_Logic_Layer;
using LoginModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class LOGIN : Form
    {
        BLL bll = new BLL();
        public LOGIN()
        {
            InitializeComponent();
        }

        private void button_Sign_In_Click(object sender, EventArgs e)
        {
            if (textBox_UserName.Text != string.Empty && textBox_Password.Text!= string.Empty)
            {
                var member = bll.getLoginByUsername(textBox_UserName.Text);
                if (member != null)
                {
                    if (member.PASSWORD == textBox_Password.Text)
                    {
                        var staff = member.STAFF;
                        var staffType = staff.STAFF_TYPE_ID1;
                        if (staffType.STAFF_TYPE_NAME.Equals("Staff"))
                        {
                            var form = new UI.Staff();
                            form.Show();
                            this.Hide();
                            form.FormClosed += Form_FormClosed;
                        }
                        else if (staffType.STAFF_TYPE_NAME.Equals("Administator"))
                        {
                            var form = new UI.Administator();
                            form.Show();
                            this.Hide();
                            form.FormClosed += Form_FormClosed;
                        }
                        else 
                        {
                            var form = new UI.WareHouseStaff();
                            form.Show();
                            this.Hide();
                            form.FormClosed += Form_FormClosed;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Password is incorrect");
                    }
                }
                else
                {
                    MessageBox.Show("Username does not exist");
                }
            }
           else
            {
                MessageBox.Show("Username or Password is not empty");
            }
        }

        
        private void Form_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Show();
        }
    }
}

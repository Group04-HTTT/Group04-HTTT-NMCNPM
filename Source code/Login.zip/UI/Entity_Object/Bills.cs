﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity_Object
{
    public class Bills
    {
        public Bills() { }
        public Bills(int Bill_id, DateTime Bill_createdate, double Total_amt, double Total_price, float Discount, double Total_money, int Mem_id)
        {
            bill_id = Bill_id;
            bill_createdate = Bill_createdate;
            total_amt = Total_amt;
            total_price = Total_price;
            discount = Discount;
            total_money = Total_money;
            mem_id = Mem_id;
        }
        public int bill_id { get; set; }
        public DateTime bill_createdate { get; set; }
        public double total_amt { get; set; } //Tổng số lượng đã mua
        public double total_price { get; set; }
        public float discount { get; set; }
        public double total_money { get; set; }
        public int mem_id { get; set; }
    }
}

namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class PRODUCT_TYPE
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PRODUCT_TYPE_ID { get; set; }

        [StringLength(100)]
        public string PRODUCT_TYPE_NAME { get; set; }

        public virtual PRODUCT_TYPE PRODUCT_TYPE1 { get; set; }

        public virtual PRODUCT_TYPE PRODUCT_TYPE2 { get; set; }
    }
}

namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("PRODUCT")]
    public partial class PRODUCT
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int PRODUCT_ID { get; set; }

        public int? PRODUCT_TYPE_ID { get; set; }

        [StringLength(100)]
        public string PRODUCT_NAME { get; set; }

        [Column(TypeName = "money")]
        public decimal? PRODUCT_PRICE { get; set; }
    }
}

namespace LoginModel
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class dbContext : DbContext
    {
        public dbContext()
            : base("name=dbContext")
        {
        }

        public virtual DbSet<BILL> BILLs { get; set; }
        public virtual DbSet<LOGIN> LOGINs { get; set; }
        public virtual DbSet<PRODUCT> PRODUCTs { get; set; }
        public virtual DbSet<PRODUCT_TYPE> PRODUCT_TYPE { get; set; }
        public virtual DbSet<STAFF> STAFFs { get; set; }
        public virtual DbSet<STAFF_TYPE_ID> STAFF_TYPE_ID { get; set; }
        public virtual DbSet<sysdiagram> sysdiagrams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BILL>()
                .Property(e => e.TOTAL_AMT)
                .HasPrecision(19, 4);

            modelBuilder.Entity<BILL>()
                .Property(e => e.TOTAL_PRICE)
                .HasPrecision(19, 4);

            modelBuilder.Entity<BILL>()
                .Property(e => e.DISCOUNT)
                .HasPrecision(19, 4);

            modelBuilder.Entity<BILL>()
                .Property(e => e.TOTAL_MONEY)
                .HasPrecision(19, 4);

            modelBuilder.Entity<LOGIN>()
                .Property(e => e.USERNAME)
                .IsUnicode(false);

            modelBuilder.Entity<LOGIN>()
                .Property(e => e.PASSWORD)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.PRODUCT_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT>()
                .Property(e => e.PRODUCT_PRICE)
                .HasPrecision(19, 4);

            modelBuilder.Entity<PRODUCT_TYPE>()
                .Property(e => e.PRODUCT_TYPE_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<PRODUCT_TYPE>()
                .HasOptional(e => e.PRODUCT_TYPE1)
                .WithRequired(e => e.PRODUCT_TYPE2);

            modelBuilder.Entity<STAFF>()
                .Property(e => e.STAFF_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<STAFF>()
                .Property(e => e.STAFF_PHONE)
                .IsUnicode(false);

            modelBuilder.Entity<STAFF>()
                .Property(e => e.STAFF_SOCIALID)
                .IsUnicode(false);

            modelBuilder.Entity<STAFF_TYPE_ID>()
                .Property(e => e.STAFF_TYPE_NAME)
                .IsUnicode(false);

            modelBuilder.Entity<STAFF_TYPE_ID>()
                .HasMany(e => e.STAFFs)
                .WithRequired(e => e.STAFF_TYPE_ID1)
                .HasForeignKey(e => e.STAFF_TYPE_ID)
                .WillCascadeOnDelete(false);
        }
    }
}

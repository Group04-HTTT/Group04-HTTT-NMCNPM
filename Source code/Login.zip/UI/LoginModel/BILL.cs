namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("BILL")]
    public partial class BILL
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int BILL_ID { get; set; }

        [Column(TypeName = "money")]
        public decimal? TOTAL_AMT { get; set; }

        [Column(TypeName = "money")]
        public decimal? TOTAL_PRICE { get; set; }

        [Column(TypeName = "money")]
        public decimal? DISCOUNT { get; set; }

        [Column(TypeName = "money")]
        public decimal? TOTAL_MONEY { get; set; }

        public int? STAFF_ID { get; set; }

        public DateTime? MODIFIED_DATE { get; set; }

        public virtual STAFF STAFF { get; set; }
    }
}

namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("STAFF")]
    public partial class STAFF
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public STAFF()
        {
            BILLs = new HashSet<BILL>();
            LOGINs = new HashSet<LOGIN>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int STAFF_ID { get; set; }

        public int STAFF_TYPE_ID { get; set; }

        [StringLength(100)]
        public string STAFF_NAME { get; set; }

        [StringLength(10)]
        public string STAFF_PHONE { get; set; }

        [StringLength(9)]
        public string STAFF_SOCIALID { get; set; }

        public DateTime? STAFF_DOB { get; set; }

        public int? STAFF_GENDER { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<BILL> BILLs { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<LOGIN> LOGINs { get; set; }

        public virtual STAFF_TYPE_ID STAFF_TYPE_ID1 { get; set; }
    }
}

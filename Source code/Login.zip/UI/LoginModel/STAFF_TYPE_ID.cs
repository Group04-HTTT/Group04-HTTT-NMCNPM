namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class STAFF_TYPE_ID
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public STAFF_TYPE_ID()
        {
            STAFFs = new HashSet<STAFF>();
        }

        [Key]
        [Column("STAFF_TYPE_ID")]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int STAFF_TYPE_ID1 { get; set; }

        [StringLength(50)]
        public string STAFF_TYPE_NAME { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<STAFF> STAFFs { get; set; }
    }
}

namespace LoginModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("LOGIN")]
    public partial class LOGIN
    {
        [Key]
        [StringLength(20)]
        public string USERNAME { get; set; }

        [StringLength(16)]
        public string PASSWORD { get; set; }

        public int? STAFF_ID { get; set; }

        public virtual STAFF STAFF { get; set; }
    }
}

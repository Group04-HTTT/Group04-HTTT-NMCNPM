﻿using Entity_Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data_Access_Layer;
using System.Data;

namespace Business_Logic_Layer
{
    public class BLL
    {
        public List<Staffs> get_Staff()
        {
            List<Staffs> kq = new List<Staffs>();
            DAL respon = new DAL();
            var Staff_List = respon.GetStaffFrom_Database();
            foreach(var nv in Staff_List)
            {
                kq.Add(nv);
            }
            return kq;
        }    
        public Products Add_Product(Products new_sp)
        {
            var respon = new DAL();
            return respon.Add_Product_DB(new_sp);
        }
        public DataTable searchProductName(string name)
        {
            string query = $"exec search_product_with_name @product_name";
            DAL dal = new DAL();
            return dal.ExecuteQueryName(query, name);
        }

        public DataTable searchProductID(int id)
        {
            string query = $"exec search_product_with_id @product_id";
            DAL dal = new DAL();
            return dal.ExecuteQueryID(query, id);
        }
        public bool check_InforLogin(string us, string pw)
        {
            var temp = new DAL();
            var user = temp.GetLoginFrom_Database();
            foreach (var users in user)
            {
                if (us == users.username && pw == users.password)
                {
                    return true;
                }
            }
            return false;
        }
        //public List<Login> get_Login(string us, string pw)
        //{
        //    List<Login> kq = new List<Login>();
        //    DAL respon = new DAL();
        //    var Staff_List = respon.GetLoginFrom_Database();
        //    foreach (var nv in Staff_List)
        //    {
        //        kq.Add(nv);
        //    }
        //    return kq;
        //}
        public Login Change_MK(Login new_Password)
        {
            var respon = new DAL();
            return respon.Change_Password(new_Password);
        }
        // Phương
        public bool CheckProductExist(int pid)
        {
            var pds = new DAL().GetProductsInfoFromDB();

            foreach (var pd in pds)
            {
                if (pd.prod_id == pid)
                    return true;
            }
            return false;
        }

        public bool CheckProductStock(int pid, int qty)
        {
            var pdstks = new DAL().GetProductsStockFromDB();

            foreach (var pdstk in pdstks)
            {
                if (pdstk.product_id == pid && pdstk.product_remaning >= qty)
                    return true;
            }
            return false;
        }


        public Products GetProduct(int pid)
        {
            var pds = new DAL().GetProductsInfoFromDB();
            foreach (var pd in pds)
            {
                if (pd.prod_id == pid)
                    return pd;
            }
            return null;
        }
        public bool AddBill(List<BillsDetail> bds, Bills b)
        {
            try
            {
                var addbill = new Data_Access_Layer.DAL().AddBillToDB(b);
                if (!addbill)
                    return addbill;
                foreach (var bd in bds)
                {
                    var adddetail = new Data_Access_Layer.DAL().AddBillDetailToDB(bd);
                    if (!adddetail)
                        return adddetail;
                    addbill = addbill && adddetail;
                }
                return addbill;
            }
            catch
            {
                return false;
            }
        }

        public int GetAutoBillID()
        {
            var bid = new Data_Access_Layer.DAL().GetAutoBillIDFromDB();
            return bid;
        }

        public Bills GetBillsWithBillID(int bid)
        {
            var b = new Data_Access_Layer.DAL().GetBillFromDB(bid);
            return b;
        }

        public List<BillsDetail> GetBillsDetailWithBillID(int bid)
        {
            var bds = new Data_Access_Layer.DAL().GetBillDetailsFromDB(bid);
            return bds;
        }
    }
}

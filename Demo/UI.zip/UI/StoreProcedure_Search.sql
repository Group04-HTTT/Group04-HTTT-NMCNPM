---Search product
create proc search_product_default
	@product_name nvarchar(100),
	@product_id	int
as begin
	select pro.PRODUCT_NAME, pro.PRODUCT_ID, pro.PRODUCT_TYPE_ID, pro.PRODUCT_PRICE
	from PRODUCT pro 
	where (pro.PRODUCT_ID = @product_id and pro.PRODUCT_NAME = @product_name)
end
go

--exec search_product_default N'New South Wales' ,1

create proc search_product_with_name
	@product_name nvarchar(100)
as begin
	select pro.PRODUCT_NAME, pro.PRODUCT_ID, pro.PRODUCT_TYPE_ID, pro.PRODUCT_PRICE
	from PRODUCT pro 
	where (pro.PRODUCT_NAME = @product_name)
end
go
exec search_product_with_name N'New South Wales' 

create proc search_product_with_id
		@product_id	int
as begin
	select pro.PRODUCT_NAME, pro.PRODUCT_ID, pro.PRODUCT_TYPE_ID, pro.PRODUCT_PRICE
	from PRODUCT pro 
	where (pro.PRODUCT_ID = @product_id)
end
go
--exec search_product_with_id 1

--select * from PRODUCT
--select pro.PRODUCT_NAME, pro.PRODUCT_ID, pro.PRODUCT_TYPE_ID, pro.PRODUCT_PRICE from PRODUCT pro where pro.PRODUCT_NAME like N'New South Wales'

CREATE PROC usp_InsertBill
(
	@bill_id INT,
	@total_amt MONEY,
	@total_price MONEY,
	@discount MONEY,
	@total_money MONEY,
	@staff_id INT
)
AS
BEGIN
	INSERT INTO dbo.BILL
	(
	    BILL_ID,
	    TOTAL_AMT,
	    TOTAL_PRICE,
	    DISCOUNT,
	    TOTAL_MONEY,
	    STAFF_ID,
	    MODIFIED_DATE
	)
	VALUES
	(   @bill_id,        -- BILL_ID - int
	    @total_amt,     -- TOTAL_AMT - money
	    @total_price,     -- TOTAL_PRICE - money
	    @discount,     -- DISCOUNT - money
	    @total_money,     -- TOTAL_MONEY - money
	    @staff_id,        -- STAFF_ID - int
	    GETDATE() -- MODIFIED_DATE - datetime
	    )
END


CREATE PROC usp_InsertBillDetail
(
	@bill_id INT,
	@product_id INT,
	@num_of_prod INT,
	@unit_price MONEY
)
AS
BEGIN
BEGIN TRAN
	DECLARE @remain INT
	SET @remain = (SELECT wh.PRODUCT_REMAINING FROM dbo.WAREHOUSE wh WHERE wh.PRODUCT_ID = @product_id)
	IF (@remain >= @num_of_prod)
	BEGIN
	INSERT INTO dbo.BILL_DETAIL
	(
	    BILL_ID,
	    PRODUCT_ID,
	    NUMBER_OF_PRODUCTS,
	    UNIT_PRICE
	)
	VALUES
	(   @bill_id,   -- BILL_ID - int
	    @product_id,   -- PRODUCT_ID - int
	    @num_of_prod,   -- NUMBER_OF_PRODUCTS - int
	    @unit_price -- UNIT_PRICE - money
	)

	UPDATE dbo.WAREHOUSE
	SET PRODUCT_REMAINING = PRODUCT_REMAINING - @num_of_prod
	WHERE PRODUCT_ID = @product_id
	END
    ELSE
	ROLLBACK TRAN
COMMIT TRAN
END 
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity_Object
{
    public class Login
    {
        //
        public Login() { }
        public Login(string Username, string Password, string Staff_TypeName)
        {
            username = Username;
            password = Password;
            staff_TypeName = Staff_TypeName;
        }
        public string username { get; set; }
        public string password { get; set; }
        public string staff_TypeName { get; set; }
    }
}

﻿using Entity_Object;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Data_Access_Layer
{
    public class DAL
    {

        public static string connectionString = @"Data Source=LAPTOP-LONG-LY\SQLEXPRESS; Initial Catalog=convinience_store;Integrated Security=True";
        public OleDbConnection Connected()
        {
            string path = "set_Connection.txt";
            var reader = new StreamReader(path);
            var query = reader.ReadLine();
            OleDbConnection oldbconnection = new OleDbConnection();
            oldbconnection.ConnectionString = query;
            //filename;
            oldbconnection.Open();
            return oldbconnection;
        }
        public List<Staffs> GetStaffFrom_Database()
        {
            var staff = new List<Staffs>();
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = "select * from STAFF";
            var er = oldbcmd.ExecuteReader();
            while (er.Read())
            {
                staff.Add(new Staffs(er.GetInt32(0), er.GetInt32(1), er.GetString(2), er.GetString(3), er.GetString(4), er.GetDateTime(5), er.GetInt32(6)));
            }
            oldbcn.Close();
            return staff;
        }
        public Products Add_Product_DB(Products new_product)
        {
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = $"insert into PRODUCT values({new_product.prodtype_id}, '{new_product.prod_name}', {new_product.prod_price});";
            oldbcmd.ExecuteNonQuery();
            oldbcn.Close();
            return new_product;
        }

        // Phung
        public DataTable ExecuteQueryName(string query, string name)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@product_name", name);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        public DataTable ExecuteQueryID(string query, int id)
        {
            DataTable data = new DataTable();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@product_id", id);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(data);
                connection.Close();
            }
            return data;
        }

        //Login
        //public List<Login> GetLoginFrom_Database()
        //{
        //    var login = new List<Login>();
        //    OleDbConnection oldbcn = Connected();
        //    OleDbCommand oldbcmd = new OleDbCommand();
        //    oldbcmd.Connection = oldbcn;
        //    oldbcmd.CommandText = "select USERNAME, PASSWORD from Login";
        //    var er = oldbcmd.ExecuteReader();
        //    while (er.Read())
        //    {
        //        login.Add(new Login(er.GetString(0), er.GetString(1)));
        //    }
        //    oldbcn.Close();
        //    return login;
        //}

        public List<Login> GetLoginFrom_Database()
        {
            var login = new List<Login>();
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = "select l.USERNAME, l.PASSWORD, st.STAFF_TYPE_NAME from LOGIN l join STAFF s on l.STAFF_ID = s.STAFF_ID join STAFF_TYPE_ID st on st.STAFF_TYPE_ID = s.STAFF_TYPE_ID";
            var er = oldbcmd.ExecuteReader();
            while (er.Read())
            {
                login.Add(new Login(er.GetString(0), er.GetString(1), er.GetString(2)));
            }
            oldbcn.Close();
            return login;
        }
        public Login Change_Password(Login new_Pass)
        {
            OleDbConnection oldbcn = Connected();
            OleDbCommand oldbcmd = new OleDbCommand();
            oldbcmd.Connection = oldbcn;
            oldbcmd.CommandText = "update Login set PASSWORD = ? where USERNAME = ?";
            oldbcmd.Parameters.AddWithValue("?", new_Pass.password);
            oldbcmd.Parameters.AddWithValue("?", new_Pass.username);
            oldbcmd.ExecuteNonQuery();
            oldbcn.Close();
            return new_Pass;
        }
        // Phương
        public bool AddBillToDB(Bills b)
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();

                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = "exec usp_InsertBill ?, ?, ?, ?, ?, ?"
                };

                cmd.Parameters.AddWithValue("?", b.bill_id);
                cmd.Parameters.AddWithValue("?", b.total_amt);
                cmd.Parameters.AddWithValue("?", b.total_price);
                cmd.Parameters.AddWithValue("?", b.discount);
                cmd.Parameters.AddWithValue("?", b.total_money);
                cmd.Parameters.AddWithValue("?", b.staff_id);
                var rd = cmd.ExecuteNonQuery();
                cnn.Close();
                return (rd >= 1);
            }
            finally
            {
                cnn.Close();
            }
        }

        public bool AddBillDetailToDB(BillsDetail bd)
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();

                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = "exec usp_InsertBillDetail ?, ?, ?, ?"
                };

                cmd.Parameters.AddWithValue("?", bd.bill_id);
                cmd.Parameters.AddWithValue("?", bd.product_id);
                cmd.Parameters.AddWithValue("?", bd.number_of_products);
                cmd.Parameters.AddWithValue("?", bd.unit_price);
                var rd = cmd.ExecuteNonQuery();
                cnn.Close();
                return (rd >= 1);
            }
            finally
            {
                cnn.Close();
            }
        }

        public bool AddBillDetailToDB2(List<BillsDetail> bds)
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                DataTable dtbd = new DataTable();
                dtbd.Columns.Add(new DataColumn("BillID", typeof(int)));
                dtbd.Columns.Add(new DataColumn("ProductID", typeof(int)));
                dtbd.Columns.Add(new DataColumn("Quantity", typeof(int)));
                dtbd.Columns.Add(new DataColumn("UnitPrice", typeof(decimal)));

                foreach (var bd in bds)
                {
                    dtbd.Rows.Add(bd.bill_id, bd.product_id, bd.number_of_products, bd.unit_price);
                }
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = "exec usp_AddBillDetail ?, ?, ?, ?"
                };

                cmd.Parameters.AddWithValue("?", dtbd);
                var rd = cmd.ExecuteNonQuery();
                cnn.Close();
                return (rd >= 1);
            }
            finally
            {
                cnn.Close();
            }
        }

        public List<Products> GetProductsInfoFromDB()
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = $"select * from PRODUCT"
                };
                var rd = cmd.ExecuteReader();
                var pds = new List<Products>();

                while (rd.Read())
                {
                    var pd = new Products();
                    pd.prod_id = rd.GetInt32(0);
                    if (rd.IsDBNull(1))
                        pd.prodtype_id = 0;
                    else pd.prodtype_id = rd.GetInt32(1);
                    if (rd.IsDBNull(2))
                        pd.prod_name = "";
                    else pd.prod_name = rd.GetString(2);

                    if (rd.IsDBNull(3))
                        pd.prod_price = 0;
                    else pd.prod_price = rd.GetDecimal(3);
                    pds.Add(pd);
                    //pds.Add(new Products(rd.GetInt32(0), rd.GetString(2), rd.GetDecimal(3), rd.GetInt32(1)));
                }
                cnn.Close();
                return pds;
            }
            finally
            {
                cnn.Close();
            }
        }


        public List<Warehouse> GetProductsStockFromDB()
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = $"select * from WAREHOUSE"
                };
                var rd = cmd.ExecuteReader();
                var pdstks = new List<Warehouse>();

                while (rd.Read())
                {
                    var stk = new Warehouse();
                    if (rd.IsDBNull(0))
                        stk.product_id = 0;
                    else stk.product_id = rd.GetInt32(0);
                    if (rd.IsDBNull(1))
                        stk.product_type_id = 0;
                    else stk.product_type_id = rd.GetInt32(1);
                    if (rd.IsDBNull(2))
                        stk.product_remaning = 0;
                    else stk.product_remaning = rd.GetInt32(2);
                    pdstks.Add(stk);
                }
                cnn.Close();
                return pdstks;
            }
            finally
            {
                cnn.Close();
            }
        }
        public int GetAutoBillIDFromDB()
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = $"SELECT TOP(1) BILL_ID FROM dbo.BILL ORDER BY BILL_ID DESC"
                };
                var rd = cmd.ExecuteReader();
                int bid = 1;
                if (rd.HasRows)
                    if (rd.Read())
                        bid = rd.GetInt32(0) + 1;
                cnn.Close();
                return bid;
            }
            finally
            {
                cnn.Close();
            }
        }

        public Bills GetBillFromDB(int bid)
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = $"SELECT * FROM dbo.BILL where BILL_ID = ?"
                };

                cmd.Parameters.AddWithValue("?", bid);

                var rd = cmd.ExecuteReader();
                var b = new Bills();
                if (rd.HasRows)
                {
                    if (rd.Read())
                    {
                        if (rd.IsDBNull(0))
                            b.bill_id = 0;
                        else b.bill_id = rd.GetInt32(0);
                        if (rd.IsDBNull(1))
                            b.total_amt = 0;
                        else b.total_amt = rd.GetDecimal(1);
                        if (rd.IsDBNull(2))
                            b.total_price = 0;
                        else b.total_price = rd.GetDecimal(2);
                        if (rd.IsDBNull(3))
                            b.discount = 0;
                        else b.discount = rd.GetDecimal(3);
                        if (rd.IsDBNull(4))
                            b.total_money = 0;
                        else b.total_money = rd.GetDecimal(4);
                        if (rd.IsDBNull(5))
                            b.staff_id = 0;
                        else b.staff_id = rd.GetInt32(5);
                        if (rd.IsDBNull(6))
                            b.modified_date = DateTime.MinValue;
                        else b.modified_date = rd.GetDateTime(6);
                    }
                }
                cnn.Close();
                return b;
            }
            finally
            {
                cnn.Close();
            }
        }

        public List<BillsDetail> GetBillDetailsFromDB(int bid)
        {
            var cnn = new OleDbConnection();
            cnn.ConnectionString = ConfigurationManager.ConnectionStrings["cnnstr"].ConnectionString;
            try
            {
                cnn.Open();
                var cmd = new OleDbCommand()
                {
                    Connection = cnn,
                    CommandText = $"SELECT * FROM dbo.BILL_DETAIL where BILL_ID = ?"
                };

                cmd.Parameters.AddWithValue("?", bid);

                var rd = cmd.ExecuteReader();
                var bds = new List<BillsDetail>();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {

                        var bd = new BillsDetail();
                        if (rd.IsDBNull(0))
                            bd.bill_id = 0;
                        else bd.bill_id = rd.GetInt32(0);
                        if (rd.IsDBNull(1))
                            bd.product_id = 0;
                        else bd.product_id = rd.GetInt32(1);
                        if (rd.IsDBNull(2))
                            bd.number_of_products = 0;
                        else bd.number_of_products = rd.GetInt32(2);
                        if (rd.IsDBNull(3))
                            bd.unit_price = 0;
                        else bd.unit_price = rd.GetDecimal(3);

                        bds.Add(bd);
                    }
                }
                cnn.Close();
                return bds;
            }
            finally
            {
                cnn.Close();
            }

        }
    }
}

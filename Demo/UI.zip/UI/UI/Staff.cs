﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Staff : Form
    {
        public Staff()
        {
            InitializeComponent();
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form search_product = new Search_Product();
            search_product.ShowDialog();
        }

        private void button_AddBill_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form addbill = new AddBill(1111);
            addbill.ShowDialog();
        }
    }
}

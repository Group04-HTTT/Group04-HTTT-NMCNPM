﻿using Business_Logic_Layer;
using Entity_Object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class Delete_Staff : Form
    {
        public Delete_Staff()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            
            BLL bll = new BLL();
            var bd = bll.get_Staff();
            ListStaff_To_ListView(listView_Staff_AtStore, bd);
        }
        private void ListStaff_To_ListView(ListView listView_Staff, List<Staffs> nv)
        {
            listView_Staff.Items.Clear();
            foreach(var staff in nv)
            {
                ListViewItem item = new ListViewItem();
                item.Text = staff.staff_id.ToString();
                item.SubItems.Add(staff.staff_name);
                item.SubItems.Add(staff.staff_phone);
                item.SubItems.Add(staff.staff_dob.ToString());
                item.SubItems.Add(staff.staff_socialid);
                item.SubItems.Add(staff.staff_gender.ToString());
                listView_Staff_AtStore.Items.Add(item);
                item.Tag = staff;
            }
        }
    }
}

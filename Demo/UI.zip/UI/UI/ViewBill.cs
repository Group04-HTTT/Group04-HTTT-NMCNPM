﻿using Entity_Object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static UI.Program;

namespace UI
{
    public partial class ViewBill : Form
    {
        public ViewBill()
        {
            InitializeComponent();
        }
        clsResize _form_resize;
        public ViewBill(int bid)
        {
            InitializeComponent();
            var b = new Business_Logic_Layer.BLL().GetBillsWithBillID(bid);
            var bds = new Business_Logic_Layer.BLL().GetBillsDetailWithBillID(bid);

            LoadBillsDetail(bds, b);

            _form_resize = new clsResize(this);
            this.Load += _Load;
            this.Resize += _Resize;
        }

        private void _Load(object sender, EventArgs e)
        {
            _form_resize._get_initial_size();
        }

        private void _Resize(object sender, EventArgs e)
        {
            _form_resize._resize();
        }

        private void LoadBillsDetail(List<BillsDetail> bds, Bills b)
        {
            label_bid.Text = b.bill_id.ToString();
            label_stfid.Text = b.staff_id.ToString();
            label_credate.Text = b.modified_date.ToString();

            listView_BillDetail.BeginUpdate();
            listView_BillDetail.Clear();

            listView_BillDetail.Columns.Add("Name", 350);
            listView_BillDetail.Columns.Add("Amount", 150);
            listView_BillDetail.Columns.Add("Unit Price", 250);
            int tt_amt = 0;
            decimal tt_uprice = 0;
            foreach (var bd in bds)
            {
                String[] d = new String[3];
                var pd = new Business_Logic_Layer.BLL().GetProduct(bd.product_id);

                d[0] = pd.prod_name;
                d[1] = bd.number_of_products.ToString();
                d[2] = bd.unit_price.ToString();

                tt_amt = tt_amt + Int32.Parse(d[1]);
                tt_uprice = tt_uprice + Decimal.Parse(d[2]);

                ListViewItem item = new ListViewItem(d);
                listView_BillDetail.Items.Add(item);
            }

            String[] tt = new String[3];
            tt[0] = "Total";
            tt[1] = tt_amt.ToString();
            tt[2] = tt_uprice.ToString();
            ListViewItem total = new ListViewItem(tt);
            listView_BillDetail.Items.Add(total);

            listView_BillDetail.View = View.Details;
            listView_BillDetail.EndUpdate();
        }
        private void ViewBill_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace UI
{
    partial class WareHouseStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WareHouseStaff));
            this.label1 = new System.Windows.Forms.Label();
            this.button_Search = new System.Windows.Forms.Button();
            this.button_Check_inventory = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(479, 67);
            this.label1.TabIndex = 34;
            this.label1.Text = "WareHouse Staff";
            // 
            // button_Search
            // 
            this.button_Search.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Search.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Search.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Search.Image = ((System.Drawing.Image)(resources.GetObject("button_Search.Image")));
            this.button_Search.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_Search.Location = new System.Drawing.Point(12, 120);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(194, 156);
            this.button_Search.TabIndex = 35;
            this.button_Search.Text = "Search product";
            this.button_Search.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_Search.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_Search.UseMnemonic = false;
            this.button_Search.UseVisualStyleBackColor = false;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // button_Check_inventory
            // 
            this.button_Check_inventory.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Check_inventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Check_inventory.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Check_inventory.Image = ((System.Drawing.Image)(resources.GetObject("button_Check_inventory.Image")));
            this.button_Check_inventory.Location = new System.Drawing.Point(12, 322);
            this.button_Check_inventory.Name = "button_Check_inventory";
            this.button_Check_inventory.Size = new System.Drawing.Size(194, 156);
            this.button_Check_inventory.TabIndex = 36;
            this.button_Check_inventory.Text = "Check inventory";
            this.button_Check_inventory.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button_Check_inventory.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_Check_inventory.UseMnemonic = false;
            this.button_Check_inventory.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(311, 120);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(180, 156);
            this.button1.TabIndex = 37;
            this.button1.Text = "Import product";
            this.button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(311, 322);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(194, 156);
            this.button2.TabIndex = 38;
            this.button2.Text = "Export product";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseMnemonic = false;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // WareHouseStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 502);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_Check_inventory);
            this.Controls.Add(this.button_Search);
            this.Controls.Add(this.label1);
            this.Name = "WareHouseStaff";
            this.Text = "WareHouseStaff";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Button button_Check_inventory;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}
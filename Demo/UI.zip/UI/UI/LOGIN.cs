﻿using Business_Logic_Layer;
using Data_Access_Layer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button_Sign_In_Click(object sender, EventArgs e)
        {           
            var username = textBox_UserName.Text;
            var password = textBox_Password.Text;           
            //if(username == string.Empty && password == string.Empty)
            //{
            //    MessageBox.Show("Username or Password is empty");
            //}
            //else
            //{
            //    var temp = new BLL();
            //    var check = temp.check_InforLogin(username, password);
            //    if(check)
            //    {
                    
            //        Form staff = new Staff();
            //        staff.ShowDialog();
            //        this.Hide();
                    
            //    }
            //    else
            //    {
            //        MessageBox.Show("Username , Password incorrect");
            //    }

            //}
            var temp = new DAL();
            var user = temp.GetLoginFrom_Database();
            foreach (var users in user)
            {
                if (username == users.username && password == users.password)
                {
                    if(users.staff_TypeName == "Staff")
                    {
                        Form staff = new Staff();
                        staff.ShowDialog();
                        //this.Hide();
                    }
                    else if(users.staff_TypeName == "Adminstator")
                    {
                        Form admin = new Administator();
                        admin.ShowDialog();
                        //this.Hide();
                    }
                    else if(users.staff_TypeName == "WarehouseStaff")
                    {
                        Form ware = new WareHouseStaff();
                        ware.ShowDialog();
                        //this.Hide();
                    }
                }
            }

        }

        private void button_ChangePassword_Click(object sender, EventArgs e)
        {
            Form change = new ChangePassword();
            change.ShowDialog();
        }
    }
}

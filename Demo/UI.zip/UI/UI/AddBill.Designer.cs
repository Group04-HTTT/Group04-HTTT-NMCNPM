﻿namespace UI
{
    partial class AddBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_AutoStaffID = new System.Windows.Forms.Label();
            this.label_AutoBillID = new System.Windows.Forms.Label();
            this.label_BillID = new System.Windows.Forms.Label();
            this.textBox_Qty = new System.Windows.Forms.TextBox();
            this.textBox_ProdID = new System.Windows.Forms.TextBox();
            this.label_Qty = new System.Windows.Forms.Label();
            this.label_ProdID = new System.Windows.Forms.Label();
            this.label_StaffID = new System.Windows.Forms.Label();
            this.label_AddBill = new System.Windows.Forms.Label();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.button_AddBill = new System.Windows.Forms.Button();
            this.button_AddItem = new System.Windows.Forms.Button();
            this.listView_BillDetail = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // label_AutoStaffID
            // 
            this.label_AutoStaffID.AutoEllipsis = true;
            this.label_AutoStaffID.BackColor = System.Drawing.SystemColors.Control;
            this.label_AutoStaffID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AutoStaffID.Location = new System.Drawing.Point(172, 110);
            this.label_AutoStaffID.Name = "label_AutoStaffID";
            this.label_AutoStaffID.Size = new System.Drawing.Size(249, 29);
            this.label_AutoStaffID.TabIndex = 63;
            this.label_AutoStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_AutoBillID
            // 
            this.label_AutoBillID.AutoEllipsis = true;
            this.label_AutoBillID.BackColor = System.Drawing.SystemColors.Control;
            this.label_AutoBillID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AutoBillID.Location = new System.Drawing.Point(172, 70);
            this.label_AutoBillID.Name = "label_AutoBillID";
            this.label_AutoBillID.Size = new System.Drawing.Size(249, 29);
            this.label_AutoBillID.TabIndex = 62;
            this.label_AutoBillID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_BillID
            // 
            this.label_BillID.AutoEllipsis = true;
            this.label_BillID.BackColor = System.Drawing.SystemColors.Control;
            this.label_BillID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_BillID.Location = new System.Drawing.Point(27, 70);
            this.label_BillID.Name = "label_BillID";
            this.label_BillID.Size = new System.Drawing.Size(163, 29);
            this.label_BillID.TabIndex = 61;
            this.label_BillID.Text = "Bill ID:";
            this.label_BillID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // textBox_Qty
            // 
            this.textBox_Qty.Location = new System.Drawing.Point(654, 157);
            this.textBox_Qty.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_Qty.Name = "textBox_Qty";
            this.textBox_Qty.Size = new System.Drawing.Size(103, 22);
            this.textBox_Qty.TabIndex = 60;
            // 
            // textBox_ProdID
            // 
            this.textBox_ProdID.Location = new System.Drawing.Point(177, 157);
            this.textBox_ProdID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox_ProdID.Name = "textBox_ProdID";
            this.textBox_ProdID.Size = new System.Drawing.Size(244, 22);
            this.textBox_ProdID.TabIndex = 59;
            // 
            // label_Qty
            // 
            this.label_Qty.AutoEllipsis = true;
            this.label_Qty.BackColor = System.Drawing.SystemColors.Control;
            this.label_Qty.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Qty.Location = new System.Drawing.Point(534, 149);
            this.label_Qty.Name = "label_Qty";
            this.label_Qty.Size = new System.Drawing.Size(163, 29);
            this.label_Qty.TabIndex = 58;
            this.label_Qty.Text = "Quantity:";
            this.label_Qty.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_ProdID
            // 
            this.label_ProdID.AutoEllipsis = true;
            this.label_ProdID.BackColor = System.Drawing.SystemColors.Control;
            this.label_ProdID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ProdID.Location = new System.Drawing.Point(27, 149);
            this.label_ProdID.Name = "label_ProdID";
            this.label_ProdID.Size = new System.Drawing.Size(169, 29);
            this.label_ProdID.TabIndex = 57;
            this.label_ProdID.Text = "Product ID:";
            this.label_ProdID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_StaffID
            // 
            this.label_StaffID.AutoEllipsis = true;
            this.label_StaffID.BackColor = System.Drawing.SystemColors.Control;
            this.label_StaffID.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_StaffID.Location = new System.Drawing.Point(27, 110);
            this.label_StaffID.Name = "label_StaffID";
            this.label_StaffID.Size = new System.Drawing.Size(163, 29);
            this.label_StaffID.TabIndex = 56;
            this.label_StaffID.Text = "Staff ID:";
            this.label_StaffID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label_AddBill
            // 
            this.label_AddBill.AutoSize = true;
            this.label_AddBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 35F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AddBill.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label_AddBill.Location = new System.Drawing.Point(376, 7);
            this.label_AddBill.Name = "label_AddBill";
            this.label_AddBill.Size = new System.Drawing.Size(291, 67);
            this.label_AddBill.TabIndex = 55;
            this.label_AddBill.Text = "ADD BILL";
            // 
            // button_Cancel
            // 
            this.button_Cancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_Cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_Cancel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_Cancel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_Cancel.Location = new System.Drawing.Point(654, 490);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(153, 42);
            this.button_Cancel.TabIndex = 54;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_Cancel.UseMnemonic = false;
            this.button_Cancel.UseVisualStyleBackColor = false;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // button_AddBill
            // 
            this.button_AddBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddBill.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddBill.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_AddBill.Location = new System.Drawing.Point(257, 490);
            this.button_AddBill.Name = "button_AddBill";
            this.button_AddBill.Size = new System.Drawing.Size(153, 42);
            this.button_AddBill.TabIndex = 53;
            this.button_AddBill.Text = "Add Bill";
            this.button_AddBill.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_AddBill.UseMnemonic = false;
            this.button_AddBill.UseVisualStyleBackColor = false;
            this.button_AddBill.Click += new System.EventHandler(this.button_AddBill_Click_1);
            // 
            // button_AddItem
            // 
            this.button_AddItem.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.button_AddItem.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_AddItem.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_AddItem.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_AddItem.Location = new System.Drawing.Point(842, 143);
            this.button_AddItem.Name = "button_AddItem";
            this.button_AddItem.Size = new System.Drawing.Size(153, 42);
            this.button_AddItem.TabIndex = 52;
            this.button_AddItem.Text = "Add Item";
            this.button_AddItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button_AddItem.UseMnemonic = false;
            this.button_AddItem.UseVisualStyleBackColor = false;
            this.button_AddItem.Click += new System.EventHandler(this.button_AddItem_Click);
            // 
            // listView_BillDetail
            // 
            this.listView_BillDetail.HideSelection = false;
            this.listView_BillDetail.Location = new System.Drawing.Point(33, 197);
            this.listView_BillDetail.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listView_BillDetail.Name = "listView_BillDetail";
            this.listView_BillDetail.Size = new System.Drawing.Size(963, 277);
            this.listView_BillDetail.TabIndex = 51;
            this.listView_BillDetail.UseCompatibleStateImageBehavior = false;
            // 
            // AddBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 539);
            this.Controls.Add(this.label_AutoStaffID);
            this.Controls.Add(this.label_AutoBillID);
            this.Controls.Add(this.label_BillID);
            this.Controls.Add(this.textBox_Qty);
            this.Controls.Add(this.textBox_ProdID);
            this.Controls.Add(this.label_Qty);
            this.Controls.Add(this.label_ProdID);
            this.Controls.Add(this.label_StaffID);
            this.Controls.Add(this.label_AddBill);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.button_AddBill);
            this.Controls.Add(this.button_AddItem);
            this.Controls.Add(this.listView_BillDetail);
            this.Name = "AddBill";
            this.Text = "AddBill";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_AutoStaffID;
        private System.Windows.Forms.Label label_AutoBillID;
        private System.Windows.Forms.Label label_BillID;
        private System.Windows.Forms.TextBox textBox_Qty;
        private System.Windows.Forms.TextBox textBox_ProdID;
        private System.Windows.Forms.Label label_Qty;
        private System.Windows.Forms.Label label_ProdID;
        private System.Windows.Forms.Label label_StaffID;
        private System.Windows.Forms.Label label_AddBill;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button button_AddBill;
        private System.Windows.Forms.Button button_AddItem;
        private System.Windows.Forms.ListView listView_BillDetail;
    }
}
﻿using Business_Logic_Layer;
using Entity_Object;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public partial class ChangePassword : Form
    {
        private Login login = null;

        public ChangePassword()
        {
            InitializeComponent();
        }

        private void ok_Click(object sender, EventArgs e)
        {
            if (textBox_Username.Text == "" || textBox_oldPass.Text == "" || textBox_newPass.Text == "" || textBox_Confirm.Text == "")
            {
                MessageBox.Show("You don't fill in !!!", "Notification");
            }
            else
            {
                if ((textBox_newPass.Text.Trim() != textBox_Confirm.Text.Trim()))
                    MessageBox.Show("New password and confirm password conflict", "Notification");
                else
                {
                    var new_Pass = new Login();
                    new_Pass.username = textBox_Username.Text;
                    new_Pass.password = textBox_Confirm.Text;
                    var servise = new BLL();
                    login = servise.Change_MK(new_Pass);
                    MessageBox.Show("You successful change password", "Notification");
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

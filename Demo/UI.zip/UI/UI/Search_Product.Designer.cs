﻿namespace UI
{
    partial class Search_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button_Search_Product;
            System.Windows.Forms.Button button_Search_ID;
            this.textBox_Search_Product = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_Search_ID = new System.Windows.Forms.TextBox();
            button_Search_Product = new System.Windows.Forms.Button();
            button_Search_ID = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_Search_Product
            // 
            button_Search_Product.BackColor = System.Drawing.SystemColors.MenuHighlight;
            button_Search_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Search_Product.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Search_Product.Location = new System.Drawing.Point(786, 178);
            button_Search_Product.Name = "button_Search_Product";
            button_Search_Product.Size = new System.Drawing.Size(172, 55);
            button_Search_Product.TabIndex = 12;
            button_Search_Product.Text = "Search";
            button_Search_Product.UseVisualStyleBackColor = false;
            button_Search_Product.Click += new System.EventHandler(this.button_Search_Product_Click);
            // 
            // textBox_Search_Product
            // 
            this.textBox_Search_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Search_Product.Location = new System.Drawing.Point(235, 182);
            this.textBox_Search_Product.Name = "textBox_Search_Product";
            this.textBox_Search_Product.Size = new System.Drawing.Size(536, 45);
            this.textBox_Search_Product.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DodgerBlue;
            this.label1.Location = new System.Drawing.Point(216, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(528, 48);
            this.label1.TabIndex = 14;
            this.label1.Text = "Search Information Product";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 255);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(945, 343);
            this.dataGridView1.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 182);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(204, 36);
            this.label2.TabIndex = 16;
            this.label2.Text = "Product Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(27, 112);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 36);
            this.label3.TabIndex = 17;
            this.label3.Text = "Product ID";
            // 
            // textBox_Search_ID
            // 
            this.textBox_Search_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_Search_ID.Location = new System.Drawing.Point(235, 103);
            this.textBox_Search_ID.Name = "textBox_Search_ID";
            this.textBox_Search_ID.Size = new System.Drawing.Size(536, 45);
            this.textBox_Search_ID.TabIndex = 18;
            // 
            // button_Search_ID
            // 
            button_Search_ID.BackColor = System.Drawing.SystemColors.MenuHighlight;
            button_Search_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            button_Search_ID.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            button_Search_ID.Location = new System.Drawing.Point(786, 99);
            button_Search_ID.Name = "button_Search_ID";
            button_Search_ID.Size = new System.Drawing.Size(172, 55);
            button_Search_ID.TabIndex = 19;
            button_Search_ID.Text = "Search";
            button_Search_ID.UseVisualStyleBackColor = false;
            button_Search_ID.Click += new System.EventHandler(this.button_Search_ID_Click);
            // 
            // Search_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(978, 622);
            this.Controls.Add(button_Search_ID);
            this.Controls.Add(this.textBox_Search_ID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label1);
            this.Controls.Add(button_Search_Product);
            this.Controls.Add(this.textBox_Search_Product);
            this.Name = "Search_Product";
            this.Text = "Search_Product";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_Search_Product;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_Search_ID;
    }
}